<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<mikhmon','mikhmon>|>aWNlbA==');









$data['LocalNagrak'] = array ('1'=>'LocalNagrak!10.0.0.1','LocalNagrak@|@nagrak','LocalNagrak#|#aGRicWNiaGM=','LocalNagrak%QRF+ MEDIA','LocalNagrak^qrf.net','LocalNagrak&Rp','LocalNagrak*10','LocalNagrak(1','LocalNagrak)','LocalNagrak=disable','LocalNagrak@!@enable');
$data['Nagrak'] = array ('1'=>'Nagrak!id-24.hostddns.us:15700','Nagrak@|@nagrak','Nagrak#|#aGRicWNiaGM=','Nagrak%QRF+ MEDIA','Nagrak^qrf.net','Nagrak&Rp','Nagrak*10','Nagrak(5','Nagrak)','Nagrak=10','Nagrak@!@enable');
$data['Warunggunung'] = array ('1'=>'Warunggunung!216.107.138.171:36131','Warunggunung@|@warunggunung','Warunggunung#|#aGRicWNiaGM=','Warunggunung%QRF+ MEDIA','Warunggunung^qrf.net','Warunggunung&Rp','Warunggunung*10','Warunggunung(5','Warunggunung)','Warunggunung=10','Warunggunung@!@enable');